const btn = document.querySelector(".create");
const please = document.querySelector(".confirm");
const tick = document.getElementById("confirm");

const name_input = document.getElementById("name");
const email_input = document.getElementById("email");
const password_input = document.getElementById("password");

btn.addEventListener("click", validate);

function validate() {
  const tick = document.getElementById("confirm");
  if (tick.checked) {
    name_input.value = "Your name*";
    name_input.style.fontFamily = "Comfortaa";
    email_input.value = "Your email* ";
    email_input.style.fontFamily = "Comfortaa";
    password_input.value = "Your password* ";
    password_input.type = "text";
    password_input.style.fontFamily = "Comfortaa";
    please.style.color = "#666666";
  } else {
    please.style.color = "#FF1934";
  }
}
