const btn = document.querySelector(".send_me_link");
const email_input = document.getElementById("email");
btn.addEventListener("click", sendMeLink);
function sendMeLink() {
  let html = " ";
  html = `Done!`;
  btn.classList.add("done");
  btn.textContent = html;
  email_input.value = "Your email* ";
  email_input.style.fontFamily = "Comfortaa";
}
