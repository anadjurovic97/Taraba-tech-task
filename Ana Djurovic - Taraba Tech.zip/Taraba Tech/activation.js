const btn = document.querySelector(".send_activation");
const email_input = document.getElementById("email");
const paragraph = document.querySelector(".resend-text");
btn.addEventListener("click", resendText);
function resendText() {
  paragraph.textContent = `Sorry something went wrong, we can sent you link. Please try again.`;
  paragraph.classList.add("sorry");
  email_input.value = "Your email* ";
  email_input.style.fontFamily = "Comfortaa";
}
